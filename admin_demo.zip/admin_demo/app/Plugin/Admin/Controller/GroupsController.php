<?php
App::uses('AdminAppController', 'Admin.Controller');
/**
 * Groups Controller
 *
 */
class GroupsController extends AdminAppController {

	public function beforeFilter() {   
		 parent::beforeFilter();
		 // Outros códigos que precisar
	}

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->Group->recursive = 0;
		$this->set('groups', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->Group->exists($id)) {
			throw new NotFoundException(__('Invalid group'));
		}
		$options = array('conditions' => array('Group.' . $this->Group->primaryKey => $id));
		$this->set('group', $this->Group->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		$this->Session->setFlash(__('Demo Restriction! The group could not be saved.'));
		return $this->redirect(array('action' => 'index'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		$this->Session->setFlash(__('Demo Restriction! The group could not be edited.'));
		return $this->redirect(array('action' => 'index'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->Session->setFlash(__('Demo Restriction! The group could not be deleted.'));
		return $this->redirect(array('action' => 'index'));
	}

}
