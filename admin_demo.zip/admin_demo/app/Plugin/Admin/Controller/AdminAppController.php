<?php

App::uses('AppController', 'Controller');

class AdminAppController extends AppController {

}
