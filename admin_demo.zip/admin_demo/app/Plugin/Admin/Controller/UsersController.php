<?php
App::uses('AdminAppController', 'Admin.Controller');
/**
 * Users Controller
 *
 */
class UsersController extends AdminAppController {

	public function login() {
		if ($this->Auth->login()) {
		    $this->redirect($this->Auth->redirect());
		} else {
		    $this->Session->setFlash(__('Invalid username or password, try again'));
		}
	}

	public function logout() {
		$this->Session->setFlash('Logout');
		$this->redirect($this->Auth->logout());
	}

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->User->recursive = 0;
		$this->set('users', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->User->exists($id)) {
			throw new NotFoundException(__('Invalid user'));
		}
		$options = array('conditions' => array('User.' . $this->User->primaryKey => $id));
		$this->set('user', $this->User->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		$this->Session->setFlash(__('Demo Restriction! The user could not be saved.'));
		return $this->redirect(array('action' => 'index'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		$this->Session->setFlash(__('Demo Restriction! The user could not be edited.'));
		return $this->redirect(array('action' => 'index'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->Session->setFlash(__('Demo Restriction! The user could not be deleted.'));
		return $this->redirect(array('action' => 'index'));
	}

}
