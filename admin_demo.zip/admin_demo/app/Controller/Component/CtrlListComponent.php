<?php
// app/controllers/components/controller_list.php
class CtrlListComponent extends Object {
    public function get() {
        $controllerClasses = App::objects('controller');

        foreach($controllerClasses as $controller) { 
            if ($controller != 'App' || $controller != 'Pages') { 
                App::import('Controller', $controller);
                $className = $controller . 'Controller';
                $actions = get_class_methods($className);
                foreach($actions as $k => $v) {
                    if ($v{0} == '_') {
                        unset($actions[$k]);
                    }
                }
                $parentActions = get_class_methods('AppController');
                //$parentActions = get_class_methods('PagesController');
                $controllers[$controller] = array_diff($actions, $parentActions);
            }
        }
		     
        return $controllers;  
    }
}
